document.addEventListener("DOMContentLoaded", function () {
  
   const mensaje = `
    <div id="bienvenida-cunori" style="text-align:center; padding: 10px; font-size: 1.1rem; color:#1d3270; font-weight: 500;">
      Bienvenido al catálogo digital de la <strong>Biblioteca del CUNORI</strong>.<br>
      Aquí puedes consultar <em>tesis</em>, <em>investigaciones</em>, <em>artículos</em> y otros documentos académicos producidos por nuestra comunidad universitaria.
    </div>
  `;
  $("#news").before(mensaje);
  
  //biblitoeca digital en encabezado si así se desea
  const navbar = document.querySelector("nav.navbar");

  if (navbar) {
    const title = document.createElement("div");
    title.classList.add("custom-navbar-title");
    title.textContent = "BIBLIOTECA DIGITAL · CUNORI";

    // Insertar después del #logo
    const logo = navbar.querySelector("#logo");
    if (logo && logo.parentNode) {
      logo.parentNode.insertBefore(title, logo.nextSibling);
    } else {
      navbar.appendChild(title); // fallback
    }
  }

  // Agregar información adicional al pie de página
  const footer = document.querySelector("footer, #opac-main-footer, #opaccredits");
  if (footer) {
    const customInfo = document.createElement("div");
    customInfo.innerHTML = `
      <div style="text-align:center; padding:10px; font-size: 0.9em;">
        <strong>Centro Universitario de Oriente – CUNORI, USAC</strong><br>
        Chiquimula, Guatemala | <a href="https://cunori.edu.gt" target="_blank">https://cunori.edu.gt</a><br>
        Biblioteca Digital
      </div>
    `;
    footer.appendChild(customInfo);
  }
});